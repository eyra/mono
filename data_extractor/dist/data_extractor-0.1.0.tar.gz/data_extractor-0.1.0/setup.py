# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['data_extractor']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'data-extractor',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Jeroen Vloothuis',
    'author_email': 'jeroen@9bitcat.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
